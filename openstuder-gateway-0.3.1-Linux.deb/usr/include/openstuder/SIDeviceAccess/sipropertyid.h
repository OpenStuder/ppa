#pragma once
#include <qglobal.h>

using SIPropertyID = quint64;
